# Callculator App

# Deskripsi Aplikasi
Callculator App adalah aplikasi kalkulator sederhana berbasis Flutter yang dapat melakukan operasi perhitungan dasar seperti penjumlahan, pengurangan, perkalian, dan pembagian. Aplikasi ini juga memiliki fitur riwayat perhitungan dan profil pengguna.

# Software yang Digunakan
Flutter (Dart)

Visual Studio Code 

GitHub (Untuk version control)

# Cara Instalasi
1.Pastikan Flutter sudah terinstall di perangkat Anda

2.Clone repo ini 
git clone https://github.com/rafiibnugroho/callculator_flutter.git
cd callculator_app

3.Jalankan flutter pub get untuk mengunduh dependensi

# Cara Menjalankan
1.Buka terminal atau command prompt di dalam folder proyek.

2.Jalankan perintah berikut : flutter run

# Demo



https://github.com/user-attachments/assets/fb9573d1-ee5b-4740-9bad-fb102a23025c



# Identitas
Nama     : Rafi Ibnugroho Wicaksono
Kelas    : XI RPL 2
No Absen : 27
Sekolah  : SMK N 1 BANTUL
Email    : rafiibnugrohowicaksonoo@gmail.com
