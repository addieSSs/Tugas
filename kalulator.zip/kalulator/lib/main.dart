import 'package:flutter/material.dart';
import 'package:expressions/expressions.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';

// Neon Blue Theme Colors
const Color backgroundBlack = Color(0xFF121212);
const Color neonBlue = Color(0xFF00FFFF);
const Color darkCard = Color(0xFF1E1E1E);
const Color neonAccent = Color(0xFF00BFFF);

void main() {
  runApp(const CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  const CalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: backgroundBlack,
        appBarTheme: const AppBarTheme(
          backgroundColor: darkCard,
          titleTextStyle: TextStyle(
            fontFamily: 'super',
            fontSize: 30,
            color: neonBlue,
          ),
          centerTitle: true,
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          backgroundColor: darkCard,
          selectedItemColor: neonAccent,
          unselectedItemColor: Colors.white70,
          selectedLabelStyle: TextStyle(fontFamily: 'biko', fontSize: 14),
          unselectedLabelStyle: TextStyle(fontFamily: 'biko', fontSize: 12),
        ),
      ),
      title: 'Kalkulator',
      home: AnimatedSplashScreen(
        splash: 'assets/logo.gif',
        splashIconSize: 500.0,
        centered: true,
        nextScreen: const MainScreen(),
        backgroundColor: backgroundBlack,
        duration: 2000,
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  String _input = '';
  String _result = '0';
  final List<String> _history = [];

  static const List<String> buttons = [
    '(', ')', '÷', ',', 'C',
    '7', '8', '9', '+', '-',
    '4', '5', '6', '×', ' ',
    '1', '2', '3', '0', '='
  ];

  static const List<String> operatorButtons = ['(', ')', '÷', 'C', '+', '-', '×', ','];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _updateInput(String value) {
    setState(() {
      _input += value;
    });
  }

  void _calculate() {
    try {
      if (_input.isEmpty) {
        _result = '0';
        return;
      }

      String evalInput = _input.replaceAll('×', '*').replaceAll('÷', '/');
      if (evalInput.contains('/0')) {
        _result = 'Error: Division by zero';
      } else {
        const evaluator = ExpressionEvaluator();
        var expression = Expression.parse(evalInput);
        var value = evaluator.eval(expression, {});
        _result = value.toString();
        _history.add('$_input = $_result');
      }
    } catch (e) {
      _result = 'Error: Invalid expression';
    }
    setState(() {});
  }

  void _clear() {
    setState(() {
      _input = '';
      _result = '0';
    });
  }

  @override
  Widget build(BuildContext context) {
    Widget currentScreen;
    switch (_selectedIndex) {
      case 0:
        currentScreen = _buildCalculatorScreen();
        break;
      case 1:
        currentScreen = _buildHistoryScreen();
        break;
      case 2:
        currentScreen = _buildProfileScreen();
        break;
      default:
        currentScreen = _buildCalculatorScreen();
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculator'),
        centerTitle: true,
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(
            minWidth: 400,
            maxWidth: 400,
            minHeight: 600,
            maxHeight: 600,
          ),
          child: currentScreen,
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.calculate),
            label: 'Kalkulator',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Riwayat',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }

  Widget _buildCalculatorScreen() {
    return Container(
      decoration: BoxDecoration(
        color: darkCard,
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(color: Colors.black45, blurRadius: 10, spreadRadius: 2),
        ],
      ),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Container(
            constraints: const BoxConstraints(minHeight: 150, maxHeight: 150),
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black87,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  _input.isEmpty ? '0' : _input,
                  style: const TextStyle(fontSize: 36, color: Colors.white),
                ),
                const SizedBox(height: 8),
                Text(
                  _result,
                  style: const TextStyle(
                    fontSize: 24,
                    color: neonAccent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 5,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.0,
              ),
              itemCount: buttons.length,
              itemBuilder: (context, index) {
                final isOperator = operatorButtons.contains(buttons[index]);
                final isEquals = buttons[index] == '=';

                return ElevatedButton(
                  onPressed: () {
                    if (buttons[index] == 'C') {
                      _clear();
                    } else if (buttons[index] == '=') {
                      _calculate();
                    } else if (buttons[index] != ' ') {
                      _updateInput(buttons[index]);
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isEquals
                        ? neonAccent
                        : isOperator
                            ? Colors.blueGrey.shade700
                            : Colors.blueGrey.shade900,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    padding: EdgeInsets.zero,
                  ),
                  child: Text(
                    buttons[index],
                    style: TextStyle(
                      fontSize: 24,
                      color: Colors.white,
                      fontWeight: isEquals ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHistoryScreen() {
    return Container(
      decoration: BoxDecoration(
        color: darkCard,
        borderRadius: BorderRadius.circular(16),
      ),
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          const Text(
            'Riwayat',
            style: TextStyle(fontFamily: 'nica', fontSize: 24, color: neonBlue),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: _history.isEmpty
                ? const Center(
                    child: Text(
                      'Kosong',
                      style: TextStyle(fontFamily: 'biko', fontSize: 18, color: Colors.white70),
                    ),
                  )
                : ListView.builder(
                    itemCount: _history.length,
                    itemBuilder: (context, index) {
                      return Card(
                        color: Colors.black54,
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        child: ListTile(
                          title: Text(
                            _history[index],
                            style: const TextStyle(color: Colors.white),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileScreen() {
    return Container(
      decoration: BoxDecoration(
        color: darkCard,
        borderRadius: BorderRadius.circular(16),
      ),
      padding: const EdgeInsets.all(16.0),
      child: Center(
        child: Column(
          children: [
            const CircleAvatar(
              radius: 60,
              backgroundImage: AssetImage('assets/images/p.png'),
              backgroundColor: backgroundBlack,
            ),
            const SizedBox(height: 24),
            const Text(
              'Hasna Sajida',
              style: TextStyle(
                fontFamily: 'biko',
                fontSize: 24,
                color: neonBlue,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Contact : hasnasajida8@gmail.com',
              style: TextStyle(fontFamily: 'biko', fontSize: 18, color: Colors.white70),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                '\nSpecialized By UI/UX Design',
                textAlign: TextAlign.center,
                style: TextStyle(color: neonAccent, fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
