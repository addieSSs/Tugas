package com.example.calculator_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
